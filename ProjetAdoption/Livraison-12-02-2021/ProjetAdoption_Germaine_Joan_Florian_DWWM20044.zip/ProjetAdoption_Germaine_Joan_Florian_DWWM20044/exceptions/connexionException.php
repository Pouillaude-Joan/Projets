<?php

class ConnexionException extends Exception
{
    
}
