<?php
require '../views/connexionRegistrationView.php';

?>