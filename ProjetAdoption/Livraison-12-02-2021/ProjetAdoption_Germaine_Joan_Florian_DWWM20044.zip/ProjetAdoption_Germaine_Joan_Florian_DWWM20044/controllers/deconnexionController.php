<?php
require_once '../helpers/ControllerHelper.php';

ControllerHelper::disconnected();

