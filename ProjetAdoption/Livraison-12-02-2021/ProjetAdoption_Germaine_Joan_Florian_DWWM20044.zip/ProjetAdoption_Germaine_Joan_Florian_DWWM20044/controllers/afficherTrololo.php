<?php

$id = $_GET['id'];

require '../views/afficherTrololView.php';
?>