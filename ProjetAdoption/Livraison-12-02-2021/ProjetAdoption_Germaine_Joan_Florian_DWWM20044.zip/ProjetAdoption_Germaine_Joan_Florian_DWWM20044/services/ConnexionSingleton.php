<?php
class ConnexionSingleton
{
    public static ?PDO $connexion = null;


    public static function getConnexion(): PDO
    {
        if (static::$connexion == null) {
            //static::$connexion = static::getConnexionByDetails();
            static::$connexion = static::getConnexionByDetails();
        }
        return static::$connexion;
    }

    public static function getConnexionByDetails(
        string $host = "simo-said09.synology.me",
        string $db = "doggocat",
        string $port = "5432",
        string $username = "doggocat_user",
        string $password = "doggocat_pass"
    ): PDO {
        $connStr = "pgsql:host=$host;port=$port;dbname=$db;user=$username;password=$password";

        try {
            $conn = new PDO($connStr);
            if ($conn) {
                return $conn;
            }
        } catch (PDOException $e) {
            echo $e->getMessage();
            static::$connexion = null;
        }
        return null;
    }

}
