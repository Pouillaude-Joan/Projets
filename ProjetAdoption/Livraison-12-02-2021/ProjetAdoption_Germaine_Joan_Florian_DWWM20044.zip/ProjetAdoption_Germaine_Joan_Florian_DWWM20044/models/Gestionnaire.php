<?php

require_once 'Client.php';

class Gestionnaire extends Client
{

    public function __construct
    (       
    )
    {
        parent::__construct();
    }
}
