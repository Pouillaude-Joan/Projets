<?php

require_once 'Client.php';

class Admin extends Client
{

    public function __construct
    (       
    )
    {
        parent::__construct();
    }
}