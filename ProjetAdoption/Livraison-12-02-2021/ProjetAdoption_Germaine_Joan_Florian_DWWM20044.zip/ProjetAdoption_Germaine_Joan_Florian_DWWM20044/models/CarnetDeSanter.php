<?php

class CarnetDeSante
{
}
